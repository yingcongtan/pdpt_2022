# Author
- Tatsuya Takanaga

# Structure of Data
5 kinds of source data  
- The first line gives column definition  
- From the 2nd line, details are as follows

Cargo_model.csv
- The label of cargo
- The demand
- The earliest departure
- The latest arrival
- The label of departure node of cargo
- The label of arrival node of cargo

Cargo_route_list.csv
- The label of cargo
- Thereafter, the cycle of the 5 columns
    - The label of truck
    - The path start point number
    - The path start node
    - The path end point number
    - The path end node

Constant.csv
- "truck_fixed_cost" is fixed cost of one truck
- "truck_running_cost" is running cost per one minute of truck
- "cargo_reloading_cost" is reloading cost per one kg of cargo
- "node_fixed_time" is fixed time per one node of truck
- "loading_variation_coefficient" is loading time per one kg of cargo

Daiya_model.csv
- The label of truck
- The label of departure node of truck
- The label of arrival node of truck
- The maximum working time of truck
- The maximum loading capacity of truck
- Thereafter, the cycle of the 3 columns
    - The lable of node
    - The arrival time of node
    - The departure time of node

Edge_list.csv
- The lable of node
- The lable of node
- The travel time from the node in the first column to the node in the second column


2 types of processed data (source data converted to object format)  
- cargo.json  
- truck.json
    - in both data, "use" can be ignored
